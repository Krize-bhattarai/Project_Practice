import random

def hangman():
    word = random.choice(["pugger", "littlepugger", "pokemon", "savewater", "superman", "thor", "tiger", "avengers", "fauna", "earth"])
    validLetter = "abcdefghijklmnopqrstuvwxyz"
    turn = 10
    guessmade = ""

    while len(word) > 0:
        main = ""
        # missed = 0

        for letter in word:
            if letter in guessmade:
                main = main + letter
            else:
                main = main + "_" + " "

        if main == word:
            print("You won!")
            print(word)
            break

        print("Guess the word:", main)
        guess = input()

        if guess in validLetter:
            guessmade = guessmade + guess
        else:
            print("Enter a valid letter")
            continue

        if guess not in word:
            turn = turn - 1
            print(f"Wrong guess! You have {turn} turns left.")
            if turn == 0:
                print("You lost!")
                print(f"The word was: {word}")
                break

name = input("Enter your name: ")
print("Welcome", name)
print("--------------")
print("Try to guess the word in less than 10 attempts")
hangman()


# import random

# def hangman():
#     word="lokesh"
#     validLetter="abcdefghijklmnopqrstuvwxyz"
#     guessmade="";
#     turn=10;
#     print("Welcome to this amazing game !")
#     while len(word)>0:
#         main=""
#         for letter in word:
#             if letter in guessmade:
#                 main=main+letter
#             else:
#                 main=main+"_"+" "
#         if main==word:
#             print("You won !")
#             print(word)
#             break

#         print("Guess the word: ",main);      
#         guess=input()

#         if guess in validLetter:
#             guessmade=guessmade+guess
#         else:
#             print("Inavlid letter");
#             continue;
#         if guess not in word:
#             turn=turn-1;
#             print(f"Wrong guess! You have {turn} turns left.")
#             if turn==0:
#                 print("You lost !")
#                 print(f"The word is {word}");
#                 break
# hangman()